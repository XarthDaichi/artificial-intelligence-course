# Ensemble of trees
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import accuracy_score

iris = load_iris()
X = iris.data
y = iris.target

seed = 42
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=seed)


depths = [1, 2, 1, 3, 4]
classifiers = [ ]

def name_by_depth(i, depth): return f"tree_index_{i}_depth_{depth}"
    
named_classifiers = [(name_by_depth(i, depth),  
                      DecisionTreeClassifier(max_depth=depth, class_weight='balanced', random_state=seed))
                     for i, depth in enumerate(depths) ]
classifiers = [ clf for (_, clf) in named_classifiers ]

# Ensemble
ensemble_clf = VotingClassifier(named_classifiers, voting='soft') #hard

# Train 
ensemble_clf.fit(X_train, y_train)

# Predict
ensemble_pred = ensemble_clf.predict(X_test)

# Results
individual_preds = [(named_classifiers[i][0], clf.predict(X_test)) 
                    for i, clf in enumerate(ensemble_clf.estimators_)]
                    
# Individual tree predictions
print()
for clf_name, individual_pred in individual_preds:
    accuracy = accuracy_score(y_test, individual_pred)
    print(f">>> Accuracy for {clf_name}: {accuracy}")

# Show ensemble prediction
print(f"\n>>> Accuracy for ensemble: {accuracy_score(y_test, ensemble_pred)}")

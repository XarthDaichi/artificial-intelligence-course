
from sklearn.datasets import make_moons

from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

from sklearn.model_selection import train_test_split

from utils import show_moons

random_seed = 42
samples = 500
noise = 30/100 # increase to make decision boundary more hard

X, y = make_moons(n_samples=samples, noise=noise, random_state=random_seed)

show_moons(X, y, size=(8,8))

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

voting_clf = VotingClassifier(
    estimators=[
        ('lr', LogisticRegression(random_state=random_seed)),
        ('rf', RandomForestClassifier(random_state=random_seed)),
        ('svc', SVC(random_state=random_seed))
    ]
)
print(f"*** Training ensemble moons {samples=:} Ensemble= LR + RF + SVC ***")
voting_clf.fit(X_train, y_train)
print("*** Scoring Ensemble *** ")
for name, clf in voting_clf.named_estimators_.items():
    print(f"{name} = {clf.score(X_test, y_test)}")
print(f"Ensemble: {voting_clf.score(X_test, y_test)}")